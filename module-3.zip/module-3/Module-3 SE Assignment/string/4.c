//4. Write a program in C to count the total number of words in a string.

#include <stdio.h>

int main() 
{
  char str[100];
  int i, wordCount = 0;

  printf("Enter a string: ");
  gets(str);
  
  if (str[0] == '\0') 
  {
    printf("The string is empty.\n");
  } 
  else 
  {
    wordCount = 1;
    
    for (i = 0; str[i] != '\0'; i++) 
	{
      if (str[i] == ' ') 
	  {
        wordCount++;
      }
    }

    printf("Total number of words: %d\n", wordCount);
  }

  return 0;
}
