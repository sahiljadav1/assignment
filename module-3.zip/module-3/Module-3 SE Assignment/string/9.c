//9. Write a program in C to find the maximum number of characters in a string.

#include <stdio.h>

int main() 
{
  char str[100];
  int i, maxCount = 0, currentCount = 0;

  printf("Enter a string: ");
  gets(str); 
  
  for (i = 0; str[i] != '\0'; i++) 
  {
    if (str[i] != ' ') 
	{
      currentCount++;
    } 
	else 
	{
      if (currentCount > maxCount)
	{
        maxCount = currentCount; 
	}
     currentCount = 0; 
    }
  }

 if (currentCount > maxCount) 
  {
    maxCount = currentCount;
  }

  printf("Maximum number of characters in a word: %d\n", maxCount);

  return 0;
}
