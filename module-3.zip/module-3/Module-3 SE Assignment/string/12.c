//12. Write a program in C to find the number of times a given word 'is' appears in the given string.

#include <stdio.h>

int main() 
{
  char str[100];
  char word[10] = "is";
  int count = 0;

  printf("Enter a string: ");
  gets(str); 
  
  char *ptr = str; 
  while ((ptr = strstr(ptr, word)) != NULL) 
  {
    count++;
	
    ptr += strlen(word); 
	
  }

  printf("The word 'is' appears %d times in the string.\n", count);

  return 0;
}
