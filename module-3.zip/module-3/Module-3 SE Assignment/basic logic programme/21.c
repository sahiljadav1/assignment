/*
21. Accept 2 numbers from user and swap 2 numbers with using 3rd variable 
and without using 3rd variable
*/

#include<stdio.h>

int main() 
{
    int num1,num2,temp;

    printf("Enter first number: ");
    scanf("%d",&num1);
    printf("Enter second number: ");
    scanf("%d",&num2);

    printf("\nBefore swapping:\n");
    printf("\nFirst number: %d", num1);
    printf("\nSecond number: %d", num2);
	printf("\n");
	
    temp = num1;
    num1 = num2;
    num2 = temp;

    printf("\nAfter swapping :\n");
    printf("\nFirst number: %d", num1);
    printf("\nSecond number: %d", num2);

    return 0;
}

