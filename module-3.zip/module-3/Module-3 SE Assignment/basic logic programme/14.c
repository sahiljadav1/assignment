//14. Find ascii value of given number



#include<stdio.h>
int main()
{
	
	int n1;
	printf("enter the number =");
	scanf("%d",&n1);
	

	printf("\nASCII value of = %c",n1);

	return 0;
	
}
