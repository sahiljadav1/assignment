// 10. find the area of a rectangular prism formula : A=2(wl+hl+hw)


#include <stdio.h>

int main() 
{
    int width,length,height,area;

    printf("Enter width of the prism: ");
    scanf("%d", &width);
    printf("Enter length of the prism: ");
    scanf("%d", &length);
    printf("Enter height of the prism: ");
    scanf("%d", &height);

    area = 2 * width * length + height * length + height * width;
    
    printf("\narea of the rectangular prism = %d", area);

    return 0;
}

