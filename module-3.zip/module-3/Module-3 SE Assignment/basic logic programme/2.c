
/*2. Write a program to make Simple calculator (to make addition, subtraction, 
multiplication, division and modulo)*/

#include<stdio.h>
int main()
{
	int a,b,addition,substraction,multiplication,divison;
	printf("\nenter of a = "); 
	scanf("%d",&a);//20	
	printf("\nenter of b = ");
	scanf("%d",&b);//30

	addition=a+b;
	printf("\naddition=%d",addition);
	
	substraction=a-b;
	printf("\nsubstraction=%d",substraction);
	
	multiplication=a*b;
	printf("\nmultiplication=%d",multiplication);
	
	divison=a/b;
	printf("\ndivison=%d",divison);
	
	
	
	
	return 0;
}

