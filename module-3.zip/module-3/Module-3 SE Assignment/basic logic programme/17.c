// 17. Calculate person�s insurance premium based on salary


#include<stdio.h>
void main()
{
	long int coverage,cwage,year;
	
	printf("current wage =");
	scanf("%ld",&cwage);
	
	printf("\nNumber of the year retirement =");
	scanf("%ld",&year);
	
	coverage=cwage*year;
	
	printf("insurance covrage =%d",coverage);

	return 0;
}
