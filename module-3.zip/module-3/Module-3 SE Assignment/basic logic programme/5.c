// 5. Find Area of Cube formula : a = 6a2

#include<stdio.h>
int main()
{
	int area;
	printf("area of cube a formula ");
	scanf("%d",&area);
	
	area=6*area*area;
	printf("area of cube %d",area);
	
	return 0;
}

