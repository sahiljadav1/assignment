//11. Find circumference of square formula : C = 4 * a

#include<stdio.h>
int main()
{
	
	int a,c;
	printf("enter the square a  =");
	scanf("%d",&a);
	
	c=4*a;
	printf("circumference of the square = %d",c);

	return 0;
	
}

