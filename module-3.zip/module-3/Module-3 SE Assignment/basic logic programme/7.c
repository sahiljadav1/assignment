// 7. Find area of Rectangle Formula : A=wl



#include<stdio.h>
int main()
{
	
	int area,width,length;
	printf("enter the width of rectangle =");
	scanf("%d",&width);
	printf("enter the length of rectangle =");
	scanf("%d",&length);
	
	area=width*length;
	printf("area of the rectangle = %d",area);
	
	return 0;
	
}
