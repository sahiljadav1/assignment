//27. Convert days into months

#include <stdio.h>


int main() 
{
    int day;

    printf("Enter number of day: ");
    scanf("%d", &day);

    daytomonth(day);

    return 0;
}

void daytomonth(day) 
{
    int month = day / 30; 
    
    printf("%d day to %d month", day, month);
}

