// 13. Find character value from ascii

#include<stdio.h>
int main()
{
	
	char c1;
	printf("enter the character =");
	scanf("%c",&c1);
	

	printf("\nASCII value of = %c",c1);
	printf("\nASCII value of = %d",c1);

	return 0;
	
}
