//9. Find circumference of Triangle formula : triangle = a + b + c


#include<stdio.h>
int main()
{
	int a,b,c,tringle;
	printf("\nenter the tringle of a= ");
	scanf("%d",&a);
	printf("\nenter the tringle of b= ");
	scanf("%d",&b);
	printf("\nenter the tringle of c= ");
	scanf("%d",&c);

	tringle = a+b+c;	
	printf("circumference of tringle is: %d",tringle);
	
	return 0;
}
