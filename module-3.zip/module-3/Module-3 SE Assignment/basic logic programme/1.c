
/*1. Display This Information using printf
a. Your Name
b. Your Birth date
c. Your Age
d. Your Addres*/



#include<stdio.h>

int main()
{
	int a;
	printf("\nyour the name = sahil jadav");
	
	int a2;
	printf("\nyour the birthdate = 31-3-2003");
	
	int a3;
	printf("\nyour the age =21");

	int a4;	
	printf("\nyour the address = ghatlodia");
	
	return 0;
}
