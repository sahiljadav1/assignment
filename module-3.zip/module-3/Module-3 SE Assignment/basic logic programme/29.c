//29. Convert minutes into seconds and hours

#include<stdio.h>

int main() 
{
    int minutes, seconds, hours;

    printf("\nEnter the number of minutes = ");
    scanf("%d", &minutes);

    seconds = minutes * 60; 

    hours = minutes / 60; 

    printf("%d minutes is equal to:\n", minutes);
    printf("%d seconds\n", seconds);
    printf("%d hours\n", hours);

    return 0;
}
