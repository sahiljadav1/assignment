/*
12. Accept number of students from user. I need to give 5 apples to each 
student. How many apples are required?
*/


#include <stdio.h>

int main() 
{
	int student;
	printf("\nNumber of student :");
	scanf("%d",&student);
	
	printf("Number of apple = %d",5*student);
	
    return 0;
}

