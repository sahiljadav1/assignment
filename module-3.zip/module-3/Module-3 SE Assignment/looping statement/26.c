//26. (1)+ (1+2) + (1+2+3) + (1+2+3+4) + ... + (1+2+3+4+...+n)


#include <stdio.h>

int main() 
{
    int n, ans=0, i, j , sum=0;
    printf("Enter the value of n: ");
    scanf("%d", &n);

   
    for (i = 1; i <= n; i++) 
	{
        sum = 0;

        for (j = 1; j <= i; j++) 
		{
            sum += j;
        }

        ans += sum;
    }

    printf("\nanswer: %d", ans);

    return 0;
}

