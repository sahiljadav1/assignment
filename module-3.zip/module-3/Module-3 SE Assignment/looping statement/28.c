//28. 1 2 3 6 9 18 27 54...

#include <stdio.h>

int main() 
{
    int n, i;
    int term = 1; 
    float multiplier = 2.0;  

    printf("enter the number of terms n: ");
    scanf("%d", &n);

    printf("\nthe sequence :");
    for (i = 1; i <= n; i++) 
	{
        printf("%d ", term); 
        
        term *= multiplier;

        if (multiplier == 2) 
		{
            multiplier = 1.5;
        } 
		else 
		{
            multiplier = 2;
        }
    }
    
    printf("\n");

    return 0;
}

