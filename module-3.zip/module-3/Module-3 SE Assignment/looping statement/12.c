//12. Program of Armstrong Number in C Using For Loop & While Loop

#include<stdio.h>;
int main()
{
	int num,digit=0,rem,power=0;
	printf("\nenter a number = ");
	scanf("%d",&num);
	
	int copy=num;
	int copy2=num;
	
	while(num!=0)
	{
		num=num/10;
		digit++;
	}
	while(copy!=0)
	{
		rem=copy%10;
		power=power+pow(rem,digit);
		copy=copy/10;
	}
	if(power==copy2)
	{
		printf("\n%d is an armstrong number",copy2);
	}
	else 
	{
		printf("\n%d is not an armstrong number",copy2);
	}
	
	return 0;
}
