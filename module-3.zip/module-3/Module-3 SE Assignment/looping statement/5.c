//5. WAP to print factorial of given number

#include <stdio.h>

int main() 
{
    int i,n;
    int factorial=1;
    printf("Enter a number: ");
    scanf("%d", &n);

    for (i = 1; i <= n; ++i) 
	{
	    factorial *= i;
    }
    printf("\nFactorial of %d = %d ", n, factorial);
    

    return 0;
}

