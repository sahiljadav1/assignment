/*
1
2 3
4 5 6
7 8 9 10
11 12 13 14 15
*/


#include<stdio.h>

int main() 
{
    int n=1, i, j, rows = 5;  
      
    for (i = 0; i < rows; i++) 
	{
        for (j = 0; j <= i; j++)
		{
            printf("%d ", n);
            n++; 
        }
        printf("\n");  
    }

    return 0;
}
