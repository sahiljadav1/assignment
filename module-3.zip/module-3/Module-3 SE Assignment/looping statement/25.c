//25. (1*1) + (2*2) + (3*3) + (4*4) + (5*5) + ... + (n*n)


#include <stdio.h>

int main() {
    int n,i,sum = 0;

    printf("Enter the value  n: ");
    scanf("%d", &n);

    for (i = 1; i <= n; ++i) 
	{
        sum += i * i;
    }

    printf("Sum = (1*1) + (2*2) + ... + (%d*%d) = %d\n", n, n, sum);

    return 0;
}

