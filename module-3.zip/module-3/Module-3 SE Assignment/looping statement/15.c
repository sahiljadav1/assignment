//15.Calculate sum of 10 numbers using of while loop


#include<stdio.h>

int main() 
{
    int count = 1 , number , sum = 0;

    printf("\nenter 10 numbers:");
    while (count <= 10) 
	{
        printf("\nnumber %d: ", count);
        scanf("%d", &number);
        
        sum += number;  
        count++;        
    }

	printf("\nsum of 10 number = %d", sum);

    return 0;
}

