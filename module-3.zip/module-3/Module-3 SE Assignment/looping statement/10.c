/*
10. Write a program you have to make a summation of first and last Digit. (E.g., 
1234 Ans: -5)
*/

#include <stdio.h>

int main() 
{
    int number, originalNumber, lastDigit, firstDigit;
    printf("Enter a number: ");
    scanf("%d", &number);    

    number = abs(number); 
    
    originalNumber = number;
    
    lastDigit = number % 10;
    
    while (number >= 10) 
	{
        number /= 10;
    }
    firstDigit = number;
    
    int sum = firstDigit + lastDigit;
    
    printf("\nThe summation of the first and last digits  %d is %d\n", originalNumber, sum);
    
    return 0;
}

