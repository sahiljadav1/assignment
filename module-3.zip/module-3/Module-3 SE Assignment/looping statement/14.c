/*14. Accept 5 numbers from user and find those numbers factorials.*/
#include<stdio.h>
int main()
{
	int num, i,fact=1,j;
	
	for(i=1;i<=5;i++)
	{
		printf("Enter the num :");
		scanf("\n%d",&num);//5
		printf("\n");
		printf("\n%d",num);
	
		fact=1;
		for(j=1;j<=num;j++)
		
	{
			fact = fact * j;
	}
	printf("Enter the factorial of %d is %d",num,fact);
}
	
	return 0;
}
