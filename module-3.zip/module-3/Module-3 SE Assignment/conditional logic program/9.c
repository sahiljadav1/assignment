/*
9. C Program to Check Uppercase or Lowercase or Digit or Special 
Character
*/

#include <stdio.h>
int main() 
{
    char ch;

    printf("Enter a character: ");
    scanf(" %c", &ch);

    if  (isupper(ch))
	{
        printf("\n%c = uppercase", ch);
    }
    else if (islower(ch)) 
	{
        printf("\n%c = alphabet", ch);
    }
    else if (isdigit(ch)) 
	{
        printf("\n%c = digit", ch);
    }
    else 
	{
        printf("\n%c = special character", ch);
    }

    return 0;
}

