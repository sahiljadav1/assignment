//33. WAP to input the week number and print week day.

#include <stdio.h>

const char* getdayofweek(int weeknumber) 
{
    switch (weeknumber) 
	{
        case 1: return "Sunday";
        case 2: return "Monday";
        case 3: return "Tuesday";
        case 4: return "Wednesday";
        case 5: return "Thursday";
        case 6: return "Friday";
        case 7: return "Saturday";
        default: return "Invalid week number";
    }
}

int main() {
    int weeknumber;

    printf("\nenter the week number (1-7): ");
    scanf("%d", &weeknumber);

    const char* day = getdayofweek(weeknumber);
    printf("\nthe day of the week is:%s", day);

    return 0;
}

