/*
30. If bill exceeds Rs. 800 then a surcharge of 18% will be charged andthe 
minimum bill should be of Rs. 256/-
*/

#include <stdio.h>

float calculatebill(float units) 
{
    float amount;

    if (units <= 350) 
	{
        amount = units * 1.20;
    } 
	else if (units > 350 && units < 600) 
	{
        amount = units * 1.50;
    } 
	else if (units >= 600 && units < 800) 
	{
        amount = units * 1.80;
    } 
	else 
	{
        amount = units * 2.00;
    }

    if (amount > 800) 
	{
        amount += amount * 0.18; 
    }

    if (amount < 256) 
	{
        amount = 256;
    }

    return amount;
}

int main() 
{
    int customerid;
    char customername[100];
    float unitsconsumed, totalamount;

   
    printf("enter customer id: ");
    scanf("%d", &customerid);

    printf("\nenter customer name: ");
    scanf(" %[^\n]%*c", &customername); 

    printf("\nenter units consumed: ");
    scanf("%f", &unitsconsumed);

    totalamount = calculatebill(unitsconsumed);

    printf("\nelectricity bill details:");
    printf("\ncustomer id: %d", customerid);
    printf("\ncustomer name: %s", customername);
    printf("\nunits consumed: %.2f", unitsconsumed);
    printf("\ntotal amount to be Paid: %.2f", totalamount);

    return 0;
}
