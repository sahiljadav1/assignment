/*
37. WAP to show
i. Monday to Sunday using switch case
ii. Vowel or Consonant using switch case
*/

#include <stdio.h>

int main() 
{
    int day;

    printf("enter a number (1-7) to display the day of the week: ");
    scanf("%d", &day);

  	 switch (day) 
	{
        case 1:
            printf("\nmonday");
            break;
        case 2:
            printf("\ntuesday");
            break;
        case 3:
            printf("\nwednesday");
            break;
        case 4:
            printf("\nthursday");
            break;
        case 5:
            printf("\nfriday");
            break;
        case 6:
            printf("\nsaturday");
            break;
        case 7:
            printf("\nsunday");
            break;  
		 default:
            printf("\ninvalid input");
		
	}

    return 0;
}

