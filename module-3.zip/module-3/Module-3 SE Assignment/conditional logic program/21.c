/*
31. Write a program in C to read any Month Number in integer and display the 
number of days for this month.
*/

#include <stdio.h>

int daysinmonth(int month, int year) 
{
    switch (month) 
	{
        case 1:  // January
        case 3:  // March
        case 5:  // May
        case 7:  // July
        case 8:  // August
        case 10: // October
        case 12: // December
            return 31;
        case 4:  // April
        case 6:  // June
        case 9:  // September
        case 11: // November
            return 30;
        case 2:  // February
            if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) 
			{
                return 29; // Leap year
            } 
			else 
			{
                return 28; // Non-leap year
            }
        default:
            return -1;
    }
}

int main() 
{
    int month, year;

    printf("enter the month number (1-12): ");
    scanf("%d", &month);

    printf("enter the year: ");
    scanf("%d", &year);

    int days = daysinmonth(month, year);

    if (days == -1) 
	{
        printf("\ninvalid month number");
    } 
	else 
	{
        printf("\nmonth %d  %d days", month, days);
    }

    return 0;
}

