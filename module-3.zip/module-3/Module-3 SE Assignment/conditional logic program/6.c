//6. Find the Character Is Vowel or Not

#include <stdio.h>


int main() {
    char ch;

    printf("Enter a character: ");
    scanf(" %c", &ch);

    
    if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') 
	{
        printf("\n%c is a vowel", ch);
    } 
	else 
	{
        printf("\n%c is not a vowel", ch);
    }

    return 0;
}

