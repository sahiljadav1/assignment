/*
2. WAP of Addition, Subtraction, Multiplication and Division using Switch 
case.(Must Be Menu Driven)
*/

#include<stdio.h>

int main() 
{
    int n, num1, num2, result;

    while (1) 
	{
        printf("\nMenu:\n");
        printf("\n1. addition");
        printf("\n2. subtraction");
        printf("\n3. multiplication");
        printf("\n4. division");
        printf("\n5. exit");
        printf("Enter your number: ");
        scanf("%d", &n);

			if (choice == 5) 
			{
            printf("\nexiting the program");
            break;
        }

        if (choice < 1 || choice > 5) 
		{
            printf("\nselect a number ");
            continue;
        }

       
        printf("Enter the first number: ");
        scanf("%d", &num1);
        printf("enter the second number: ");
        scanf("%d", &num2);

        switch (n) 
		{
            case 1:
                result = num1 + num2;
                printf("\nresult of addition: %d", result);
                break;

            case 2:
                result = num1 - num2;
                printf("result of subtraction: %d", result);
                break;

            case 3:
                result = num1 * num2;
                printf("\nresult of multiplication: %d", result);
                break;

            case 4:
                if (num2 != 0) 
				{
                    result = num1 / num2;
                    printf("\nresult of division: %d", result);
                } 
				else 
				{
                    printf("\nnot allowed");
                }
                break;

            default:
                printf("\ninvalid choice");
                break;
        }
    }

    return 0
}
