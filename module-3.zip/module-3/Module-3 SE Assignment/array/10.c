//10.WAP to perform Palindrome number using for loop and function

#include<stdio.h>;
int main()
{
	int num,reverse=0,rem;
	printf("\nenter a number = ");
	scanf("%d",&num);
	int copy=num;
	
	for (; num != 0; num /= 10) 
	{
        rem = num % 10;
        reverse = reverse * 10 + rem;
    }
    

	if(reverse==copy)
	{
		printf("\n%d palindrom number",copy);
	}
	else
	{
		printf("\nnot palindrom number",copy);
	}
	return 0;
	
}
