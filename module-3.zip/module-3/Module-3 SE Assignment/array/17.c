//17.WAP to show difference between Structure and Union.

#include <stdio.h>

struct Student 
{
  char name[50];
  int roll_no;
  float marks;
};

union Data 
{
  int i;
  float f;
  char str[20];
};

int main() 
{
  struct Student s1;
  strcpy(s1.name, "sahil jadav");
  s1.roll_no = 10;
  s1.marks = 85.5;

  printf("Structure Example:\n");
  printf("Name: %s\n", s1.name);
  printf("Roll No: %d\n", s1.roll_no);
  printf("Marks: %.2f\n", s1.marks);

  union Data data;
  data.i = 10;
  printf("\nUnion Example:\n");
  printf("Integer: %d\n", data.i);

  data.f = 3.14;
  printf("Float: %.2f\n", data.f);

  strcpy(data.str, "Hello");
  printf("String: %s\n", data.str);

  return 0;
}
